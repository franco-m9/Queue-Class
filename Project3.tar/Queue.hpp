#include "Queue.h"
#include <deque>
#include <iostream>

using namespace std;
using namespace cop4530;

template<typename T>
Queue<T>::Queue()
{

}

template<typename T>			// how would i do this
Queue<T>::~Queue()
{

}

template<typename T>
Queue<T>::Queue(const Queue &rhs)
{
deque<T> Q_(rhs.Q_);
}

template<typename T>
Queue<T>::Queue(Queue &&rhs)
{
deque<T> Q_(move(rhs.Q_));
}

template<typename T>
Queue<T>& Queue<T>::operator=(const Queue &rhs)		// compile issue
{
Q_ = rhs.Q_;
return this;
}

template<typename T>
Queue<T>& Queue<T>::operator=(Queue &&rhs)
{
Q_ = move(rhs.Q_);
return this;
}

template<typename T>
T& Queue<T>::back()
{
return Q_.back();
}

template<typename T>
const T& Queue<T>::back() const
{
return Q_.back();
}

template<typename T>
bool Queue<T>::empty() const
{
return Q_.empty();
}

template<typename T>
T& Queue<T>::front()
{
return Q_.front();
}

template<typename T>
const T& Queue<T>::front() const
{
return Q_.front();
}

template<typename T>
void Queue<T>::pop()
{
Q_.pop_front();
}

template<typename T>
void Queue<T>::push(const T& val)
{
Q_.push_back(val);
}

template<typename T>
void Queue<T>::push(T&& val)
{
Q_.push_back(move(val));			// move if possible ?
}

template<typename T>
int Queue<T>::size()
{
return Q_.size();
}
