#include "Queue.h"
#include <sstream>
#include <string>
#include <iostream>
#include <vector>
#include <fstream>

using namespace cop4530;
using namespace std;

int parse(string input);
vector<int>& parse2(string exe, vector<int>& intro);
bool isCity(string city, vector<string> cities, int amt);
int cityIndex(string c, vector<string> ci, int amnt);

int main(int argc, char *argv[])
{
string another;
string file = argv[1];
ifstream a;
string line;
vector<string> locations;
vector<vector<int>> matrix;
vector<int> intro;
Queue<vector<int>> breadth;
vector<int> container, container2;
string sourcecity, endcity;
int check, flightcost = 0;

a.open(file);

if(!a.is_open())
return false;

else
{
	while(getline(a,line))
	{
	locations.push_back(line);
	}

cout << locations[0] << " " << "cities:" << endl;
int amount = parse(locations[0]);
for(int i=1;i<(amount+1);i++)
cout << "\t" << locations[i] << endl;
cout << endl << "direct flights between cities" << endl;
cout << "-------------------------" << endl;


for(int i=amount+1;i<locations.size();i++)
{
parse2(locations[i],intro);
matrix.push_back(intro);
intro.clear();
}

for(int i=1;i<amount+1;i++)
{
cout << locations[i];
cout << ":" << endl;
	for(int j=0;j<amount;j++)
	{
		if(matrix[i-1][j]!=0 && matrix[i-1][j]!=-1)
		{
		cout << "\t";
		cout << locations[j+1] << "," << " $" << matrix[i-1][j] << endl;
		}
	}

}

cout << "------------------------" << endl << endl;

do
{
cout << "Source city : ";
getline(cin,sourcecity,'\n');
cout << "Destination city : ";
getline(cin,endcity,'\n');
cout << "finding min_hop route...." << endl;

if(isCity(sourcecity,locations,amount)==false)
{
cout << "\t" << "path not found, source city, " << sourcecity << ", not on the map" << endl << endl;
do
{
cout << "Search another route? (Y/N)";
getline(cin,another,'\n');
}
while(another!="n"&& another!="N" && another!="y" && another!="Y");
}
else if(isCity(endcity,locations,amount)==false)
{
cout << "\t" << "path not found, destination city, " << sourcecity << ", not on the map" << endl << endl;
do
{
cout << "Search another route? (Y/N)";
getline(cin,another,'\n');
}
while(another!="n"&& another!="N" && another!="y" && another!="Y");
}
else if(sourcecity==endcity)
{
cout << "\t" <<sourcecity << ", $0" << endl;
do
{
cout << "Search another route? (Y/N)";
getline(cin,another,'\n');
}
while(another!="n"&& another!="N" && another!="y" && another!="Y");
}
else
{
char * visited = new char[amount];
for(int i=0;i<amount;i++)
visited[i]='n';
int begin = cityIndex(sourcecity, locations, amount);
int end = cityIndex(endcity, locations, amount);
visited[begin] = 'y';

int increment = 0;
while(increment!=amount)
{
	if(matrix[begin][increment]!=0 && matrix[begin][increment]!=-1)
	{
	container.push_back(begin);
	container.push_back(increment);
	breadth.push(container);
	container.clear();
	}
increment++;
}

while(breadth.empty()==false)
{
container = breadth.front();
container2 = container;
check = container.back();
visited[check]='y';
container.clear();

if(check==end)
	break;
breadth.pop();

int counter = 0;
while(counter!=amount)
{
	if(visited[counter]!='y' && matrix[check][counter]!=0 && matrix[check][counter]!=-1)
	{
	container = container2;
	container.push_back(counter);
	breadth.push(container);
	visited[counter]='y';
	container.clear();
	}
counter++;
}

}

cout << endl;

cout << "\t" << locations[container2[0]+1];

for(int i=1;i<container2.size();i++)
cout << "-> " << locations[container2[i]+1];

for(int i=0;i<container2.size()-1;i++)
flightcost = flightcost + matrix[container2[i]][container2[i+1]];

cout << ", $"; 
cout << flightcost << endl;

flightcost = 0;
container2.clear();
for(int i=0;i<amount;i++)
visited[i]='n';
do
{
cout << "Search another route? (Y/N)";
getline(cin,another,'\n');
}
while(another!="n"&& another!="N" && another!="y" && another!="Y");
}


}
while(another=="Y" || another=="y");

	return 0;
}
}

int parse(string input)
{
int numberofcities;
istringstream output(input);
output>>numberofcities;
return numberofcities;
}

vector<int>& parse2(string exe, vector<int>& intro)
{
istringstream iss(exe);
string label;
int actuallabel;

	while(iss>>label)
	{
	actuallabel=parse(label);
	intro.push_back(actuallabel);
	}
return intro;
}

bool isCity(string city, vector<string> cities, int amt)
{
for(int i=1; i<amt+1;i++)
{
	if(cities[i]==city)
	return true;
}
	return false;
}

int cityIndex(string c, vector<string> ci, int amnt)
{
for(int index=1;index<amnt+1;index++)
{
	if(ci[index]==c)
	return index-1;
}
return 0;
}
